const userList = document.getElementById('user-list');

fetch('https://randomuser.me/api/?results=100') // Fetching 50 random users
  .then(response => response.json())
  .then(data => {
    data.results.forEach(user => {
      const userDiv = document.createElement('div');
      userDiv.innerHTML = `
        <img src="${user.picture.large}" alt="User Image">
        <p><strong>Name:</strong> ${user.name.title} ${user.name.first} ${user.name.last}</p>
        <p><strong>Gender:</strong> ${user.gender}</p>
        <p><strong>Email:</strong> ${user.email}</p>
        <p><strong>Location:</strong> ${user.location.city}, ${user.location.state}, ${user.location.country}</p>
        <p><strong>Phone:</strong> ${user.phone}</p>
        <hr>
      `;
      userList.appendChild(userDiv);
    });
  })
  .catch(error => {
    console.error('Error fetching user data:', error);
  });