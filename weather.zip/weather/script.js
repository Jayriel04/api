/* script.js */
const apiKey = '5bd350abd7d24f08ba871118240612';
const locationSelect = document.getElementById('locationSelect');
const weatherData = document.getElementById('weatherData');

locationSelect.addEventListener('change', () => {
    const selectedLocation = locationSelect.value;
    const apiUrl = `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${selectedLocation}`;

    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            let temperature = data.current.temp_c;
            let temperatureEmoji = temperature >= 30 ? '🔥' : '❄️';

            weatherData.innerHTML = `
                <h2>${data.location.name}</h2>
                <p>Temperature: ${temperature}°C ${temperatureEmoji}</p>
                <p>Condition: ${data.current.condition.text}</p>
                <p>Humidity: ${data.current.humidity}%</p>
                <p>Wind Speed: ${data.current.wind_kph} km/h</p>
                <p>Feels Like: ${data.current.feelslike_c}°C</p>
                <p>Pressure: ${data.current.pressure_mb} mb</p>
                <p>Visibility: ${data.current.vis_km} km</p>
                <p>Precipitation: ${data.current.precip_mm} mm</p>
            `;
        })
        .catch(error => {
            console.error('Error fetching weather data:', error);
        });
});