function fetchUniversities() {
    const selectedCountry = document.getElementById('country-select').value;
    const apiUrl = `http://universities.hipolabs.com/search?country=${selectedCountry}`;
  
    fetch(apiUrl)
      .then(response => response.json())
      .then(data => {
        const universitiesList = document.getElementById('universities-list');
        universitiesList.innerHTML = ''; // Clear previous list
  
        data.forEach(university => {
          const listItem = document.createElement('li');
          listItem.textContent = university.name;
          universitiesList.appendChild(listItem);
        });
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });
  }